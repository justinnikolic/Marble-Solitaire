package cs3500.marblesolitaire.view;


import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * This class represents a MarbleSolitaireView as text.
 */
public class MarbleSolitaireTextView implements MarbleSolitaireView {
  public MarbleSolitaireModelState model;


  /**
   * This constructors has one parameter which is the model.
   *
   * @param model is a MarbleSolitaireModelState, which represents the current state of the model.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState model) {
    this.model = model;


  }

  @Override
  public String toString() {
    StringBuilder gameBoard = new StringBuilder();
    int armSize = model.getBoardSize() / 3 + 2;
    for (int sRow = 0; sRow < this.model.getBoardSize(); sRow++) {
      int sCol;
      for (sCol = 0; sCol < this.model.getBoardSize(); sCol++) {
        if (this.model.getSlotAt(sRow, sCol) == MarbleSolitaireModelState.SlotState.Empty) {
          gameBoard.append("_");
        } else if (this.model.getSlotAt(sRow, sCol) ==
                MarbleSolitaireModelState.SlotState.Invalid) {
          gameBoard.append(" ");
        } else if (this.model.getSlotAt(sRow, sCol) ==
                MarbleSolitaireModelState.SlotState.Marble) {
          gameBoard.append("O");

          // check if we're at the right edge of the board
          if ((sCol != model.getBoardSize() - 1) &&
                  (this.model.getSlotAt(sRow, sCol + 1) ==
                          MarbleSolitaireModelState.SlotState.Invalid)) {
            break;
          }
        }

        if (sCol != model.getBoardSize() - 1) {
          gameBoard.append(" ");
        }

      }

      if (sRow != model.getBoardSize() - 1) {
        gameBoard.append("\n");
      }
    }
    return gameBoard.toString();
  }
}

